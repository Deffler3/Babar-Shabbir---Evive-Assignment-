package com.babar;

import com.babar.beans.CreditBean;
import com.babar.beans.MovieBean;
import com.babar.beans.TVBean;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 *
 * @author babar
 */
public class Main {

	public static void main(String[] args) {
		Main main = new Main();
		
		System.out.println("\n\nNumber of actors who worked in at least one TV show and a Movie: " + main.getNumActorsInTVandMovies("2017-12-01", "2017-12-31"));
	}

	/**
	 * Get the number of actors who worked in at least one TV show AND a movie
	 * within the specified date range
	 *
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public int getNumActorsInTVandMovies(String startDate, String endDate) {
		int num = 0;
		List<MovieBean> movieList = MediaInfoClient.instance().getMovieList(startDate, endDate, 1);
		System.out.println("Number of movies: " + (movieList != null ? movieList.size() : "0"));

		// if no movies found, we cannot find actors who worked in both Movies and TV shows
		if (movieList != null && movieList.size() > 0) {
			List<TVBean> tvList = MediaInfoClient.instance().getTVList(startDate, endDate, 1);
			System.out.println("Number of TV shows: " + (tvList != null ? tvList.size() : "0"));

			// if no TV shows found, we cannot find actors who worked in both Movies and TV shows
			if (tvList != null && tvList.size() > 0) {
				// get the credits of all tv shows
				Set<CreditBean> tvCredits = new HashSet<>();
				for (TVBean tvBean : tvList) {
					Set<CreditBean> credits = MediaInfoClient.instance().getCredits(tvBean.getId(), false);
					if (credits != null) {
						tvCredits.addAll(credits);
					}
				}
				System.out.println("number of actors found for TV shows: " + tvCredits.size());

				// get the credits of all movies
				Set<CreditBean> movieCredits = new HashSet<>();
				for (MovieBean mBean : movieList) {
					Set<CreditBean> credits = MediaInfoClient.instance().getCredits(mBean.getId(), true);
					if (credits != null) {
						movieCredits.addAll(credits);
					}
				}
				System.out.println("number of actors found for Movies shows: " + tvCredits.size());

				// whichever list is shorter loop through that and check if it exists in the other list
				// CreditBean overrides the hashCode() to compare based on the "credit_id" field assuming 
				// that that is the identifier of the any individula actor
				if (movieCredits.size() < tvCredits.size()) {
					for (CreditBean cBean : movieCredits) {
						if (tvCredits.contains(cBean)) {
							num++;
						}
					}
				} else {
					for (CreditBean cBean : tvCredits) {
						if (movieCredits.contains(cBean)) {
							num++;
						}
					}
				}
			}
		}
		return num;
	}

}
