package com.babar;

import com.babar.beans.CastDataBean;
import com.babar.beans.CreditBean;
import com.babar.beans.MovieBean;
import com.babar.beans.MovieDataBean;
import com.babar.beans.TVBean;
import com.babar.beans.TVDataBean;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 *
 * @author babar
 */
public class MediaInfoClient {

	/*
	 * base API URL, should be in the configurations
	 */
	private static final String BASE_URL = "http://api.themoviedb.org/3";
	/*
	 * API key, should be in the configurations
	 */
	private static final String API_KEY_PARAM = "api_key=606aaffd7ca10f0b80804a1f0674e4e1";
	/**
	 * date format
	 */
	private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
	/*
	 * Gson to read json response, date format in the response is 'yyyy-MM-dd'
	 */
	private static Gson GSON;
	/**
	 * singleton instance
	 */
	private static MediaInfoClient instance;
	/**
	 * OKHTTP to send API request
	 */
	private final OkHttpClient httpClient;

	/**
	 * constructor
	 */
	private MediaInfoClient() {
		this.httpClient = new OkHttpClient();
		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.registerTypeAdapter(Date.class, new DateDeserializer());
		GSON = gsonBuilder.create();
	}

	/**
	 * returns the singleton instance
	 *
	 * @return
	 */
	public synchronized static MediaInfoClient instance() {
		if (instance == null) {
			instance = new MediaInfoClient();
		}
		return instance;
	}

	/**
	 * gets the list of movies within the specified time interval starting from
	 * the given page number
	 *
	 * @param startDate
	 * @param endDate
	 * @param page
	 * @return
	 */
	public List<MovieBean> getMovieList(String startDate, String endDate, int page) {
		List<MovieBean> movieList = new ArrayList<>();
		try {
			String url = BASE_URL + "/discover/movie?primary_release_date.gte=" + startDate + "&primary_release_date.lte=" + endDate + "&page=" + page + "&" + API_KEY_PARAM;

			String res = getResponse(url);

			if (res != null) {
				MovieDataBean mdb = GSON.fromJson(res, MovieDataBean.class);
				if (mdb != null) {
					System.out.println("page: " + mdb.getPage() + ", total pages: " + mdb.getTotalPages() + ", total results: " + mdb.getTotalResults());

					if (mdb.getResults() != null && mdb.getResults().size() > 0) {
						movieList.addAll(mdb.getResults());
					}

					// if there are more pages to be read, send another request
					if (mdb.getPage() < mdb.getTotalPages()) {
						movieList.addAll(getMovieList(startDate, endDate, page + 1));
					}
				}
			}
		} catch (JsonSyntaxException | IOException | InterruptedException | NumberFormatException e) {
			try (PrintWriter pw = new PrintWriter(System.err)) {
				pw.write("There was an error while processing request for list of movies, startDate '" + startDate + "', endDate '" + endDate + "', page '" + page + "'");
				e.printStackTrace(pw);
				pw.flush();
			}
		}
		return movieList;
	}

	/**
	 * gets the list of TV shows within the specified time interval starting
	 * from the given page number
	 *
	 * @param startDate
	 * @param endDate
	 * @param page
	 * @return
	 */
	public List<TVBean> getTVList(String startDate, String endDate, int page) {
		List<TVBean> tvList = new ArrayList<>();
		try {
			String url = BASE_URL + "/discover/tv?include_null_first_air_dates=false&first_air_date.gte=" + startDate + "&first_air_date.lte=" + endDate + "&page=" + page + "&" + API_KEY_PARAM;

			String res = getResponse(url);
			if (res != null) {
				TVDataBean tvdb = GSON.fromJson(res, TVDataBean.class);
				if (tvdb != null) {
					System.out.println("page: " + tvdb.getPage() + ", total pages: " + tvdb.getTotalPages() + ", total results: " + tvdb.getTotalResults());

					if (tvdb.getResults() != null && tvdb.getResults().size() > 0) {
						tvList.addAll(tvdb.getResults());
					}

					// if there are more pages to be read, send another request
					if (tvdb.getPage() < tvdb.getTotalPages()) {
						tvList.addAll(getTVList(startDate, endDate, page + 1));
					}
				}
			}
		} catch (JsonSyntaxException | IOException | InterruptedException | NumberFormatException e) {
			try (PrintWriter pw = new PrintWriter(System.err)) {
				pw.write("There was an error while processing request for list of TV shows, startDate '" + startDate + "', endDate '" + endDate + "', page '" + page + "'");
				e.printStackTrace(pw);
				pw.flush();
			}
		}
		return tvList;
	}

	/**
	 * gets the list of credits for the TV show for the given id, returns a set
	 * in order to avoid duplicate credits based on the "credit_id"
	 *
	 * @param id
	 * @param isMovie
	 * @return
	 */
	public Set<CreditBean> getCredits(int id, boolean isMovie) {
		Set<CreditBean> data = new HashSet<>();
		try {
			String url = BASE_URL + (isMovie ? "/movie/" : "/tv/") + id + "/credits?" + API_KEY_PARAM;

			String res = getResponse(url);
			if (res != null) {
				CastDataBean cast = GSON.fromJson(res, CastDataBean.class);
				if (cast != null && cast.getCast() != null) {
					System.out.println("number of actors found: " + cast.getCast().size() + ", for " + (isMovie ? "movie" : "tv") + " id: " + id);
					data = cast.getCast();
				}
			}
		} catch (JsonSyntaxException | IOException | InterruptedException | NumberFormatException e) {
			try (PrintWriter pw = new PrintWriter(System.err)) {
				pw.write("There was an error while processing request to retrieve TV show credits for id '" + id + "'");
				e.printStackTrace(pw);
				pw.flush();
			}
		}
		return data;
	}

	/**
	 * get the response as string from the provided URL
	 *
	 * @param url
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private String getResponse(String url) throws IOException, InterruptedException {
		String res = null;
		// build request
		Request request = new Request.Builder().url(url).build();
		// send request and get response
		Response response = httpClient.newCall(request).execute();

		// verify if the request was denied to wait before another request can be entertained as the remote service imposes limits
		int retryAfter = -1;
		if (response.code() == 429 && response.header("Retry-After") != null) {
			// retry-after header contains the number of seconds to wait before sending a new request
			retryAfter = Integer.valueOf(response.header("Retry-After"));
		}

		if (retryAfter > 0) {
			retryAfter++;
			System.out.println("retrying after: " + retryAfter + "s for url '" + url + "'");
			Thread.sleep((retryAfter * 1000));
			res = getResponse(url);

		} else {
			// read the response
			ResponseBody body = response.body();
			if (body != null) {
				res = body.string();
			}
		}
		return res;
	}

	/**
	 * custom "date" deserializer
	 */
	private class DateDeserializer implements JsonDeserializer<Date> {

		/**
		 *
		 * @param json
		 * @param type
		 * @param context
		 * @return
		 * @throws JsonParseException
		 */
		@Override
		public Date deserialize(JsonElement json, java.lang.reflect.Type type, JsonDeserializationContext context) throws JsonParseException {
			Date date = null;
			try {
				String str = json.getAsJsonPrimitive().getAsString();
				if (str != null && !"".equals(str.trim())) {
					date = DATE_FORMAT.parse(str);
				}
			} catch (ParseException e) {
				System.out.println("failed to parse date, error '" + e.getMessage() + "'");
			}
			return date;
		}
	}
}
