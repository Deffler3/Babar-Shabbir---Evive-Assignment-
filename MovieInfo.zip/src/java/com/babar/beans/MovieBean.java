package com.babar.beans;

import java.util.Date;
import java.util.List;
import lombok.Data;

/**
 *
 * @author babar
 */
@Data
public class MovieBean {
	private int vote_count;
	private int id;
	private boolean video;
	private float vote_average;
	private String title;
	private float popularity;
	private String poster_path;
	private String original_language;
	private String original_title;
	private List<Integer> genere_ids;
	private String backdrop_path;
	private boolean adult;
	private String overview;
	private Date release_date;
	
	
}
