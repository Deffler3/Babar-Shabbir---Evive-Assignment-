package com.babar.beans;

import com.google.gson.annotations.SerializedName;
import java.util.Objects;
import lombok.Data;

/**
 *
 * @author babar
 */
@Data
public class CreditBean {

	private String character;
	@SerializedName("credit_id")
	private String creditId;
	private int id;
	private String name;
	private int gender;
	@SerializedName("profile_path")
	private String profilePath;
	private int order;

	/**
	 *
	 * @param obj
	 * @return
	 */
	@Override
	public boolean equals(Object obj) {
		boolean isEqual = false;
		if (obj != null && obj instanceof CreditBean) {
			CreditBean mdb = (CreditBean) obj;
			// if either the credit id is same or name and gender is same
			isEqual = (mdb.getCreditId() != null && mdb.getCreditId().equals(creditId));
		}
		return isEqual;
	}

	/**
	 *
	 * @return
	 */
	@Override
	public int hashCode() {
		int hash = 3;
		hash = 37 * hash + Objects.hashCode(this.creditId);
		return hash;
	}
}
