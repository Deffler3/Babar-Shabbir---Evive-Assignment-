package com.babar.beans;

import java.util.Set;
import lombok.Data;

/**
 *
 * @author babar
 */
@Data
public class CastDataBean {
	private Set<CreditBean> cast;
	private int id;
}
