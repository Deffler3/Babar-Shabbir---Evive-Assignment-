package com.babar.beans;

import java.util.Date;
import java.util.List;
import lombok.Data;

/**
 *
 * @author babar
 */
@Data
public class TVBean {
	private String original_name;
	private List<Integer> genere_ids;
	private String name;
	private float popularity;
	private int vote_count;
	private Date first_air_date;
	private String backdrop_path;
	private String original_language;
	private int id;
	private float vote_average;
	private String overview;
	private String poster_path;
	private List<String> origin_country;
}
